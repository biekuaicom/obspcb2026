# PCB 显微镜 AR 标注 — 里程碑检查清单（MILESTONES）

| 字段 | 值 |
|------|-----|
| 版本 | **v0.1.1** |
| 日期 | 2026-11-09（Asia/Shanghai） |
| 对齐 | `PROJECT_BRIEF.md` §7、`HANDOFF.md` |
| 用法 | 勾选 `[x]`；每阶段满足 **Done when** 再进入下一阶段 |
| 修订 | 决策 **D1/D2/D3/D4/D5/D9/D12** 已确认 2026-11-09（Asia/Shanghai） |

---

## 本轮视觉工程应先实现（对齐 HANDOFF §2）

> **现在先做这一刀，不等全部规格拍板。**

- [ ] 按简报脚手架：`src/app`、`src/vision`、`src/model`、`tests/`（及 `calib` 占位）
- [ ] 实现 **`VideoCaptureThread`**（OpenCV → 信号发帧；可安全 `stop`；无相机可用假帧/视频）
- [ ] **PyQt6 主窗口壳**：`QGraphicsScene` 视频底图 + 空标注层 + 右侧 `QDockWidget` 占位
- [ ] **`PCBAffineTracker` / `LocalGlobalTracker` 桩**（类签名、文档字符串、空实现或假单位矩阵）
- [ ] **测试计划**：`tests/README.md` 或 `docs/TEST_PLAN.md`（配准成功/失败、投影可见性、JSON 序列化冒烟）
- [ ] 可运行入口：`python -m app.main`（或等价）打开空壳

**本轮视觉 Done when**（HANDOFF）：可启动壳应用 + Capture 线程 + 两个 Tracker 桩 + 测试计划。  
TECH_SPEC 定稿后做一次接口对齐（命名/信号/矩阵方向）。

**一句话切片**：脚手架 + Capture 线程 + 主窗口壳 + 双 Tracker 桩 + 测试计划。

---

## MVP（桌面可演示）

对齐简报 §7 MVP，细化验收点。

### 建图与数据

- [ ] 半自动网格抓图 **或** 全局图导入（外部 Hugin/PTGui 结果可导入即可）
- [ ] 瓦片重叠提示（目标 20%–30%）；错位不静默吞掉
- [ ] JSON 数据模型落地（见 `DATA_MODEL.md`）+ 至少一块样例板工程
- [ ] `ProjectStore.load/save`；重开工程状态保持

### 采集与 UI 壳

- [ ] `VideoCaptureThread` + QGraphics 视频底图
- [ ] 主窗口：中央 Canvas + 右侧 Dock；菜单/工具栏可极简
- [ ] 无相机降级路径可用

### 配准与叠加

- [ ] **主路径** `LocalGlobalTracker` 真实现可跑通；`PCBAffineTracker` 作降级（可为增强桩）
- [ ] 全局标注投影到当前视口；中心不在视口内不渲染
- [ ] 跟踪失败降级：沿用上一帧矩阵，**TTL = 0.8 s**；超时冻结标注并提示「跟踪丢失」
- [ ] 状态色：未核对 **红** / 已核对 **绿**（`doubt`/黄 **不进 MVP**，见 v0.5）

### 编辑与绑定

- [ ] 画布内联编辑 ≤3 个 `core_params`
- [ ] 侧栏编辑 `extended_params`；与画布选中双向联动
- [ ] 改 status 即时变色并写回 JSON

### 质量

- [ ] 基础测试计划文档 + 至少若干自动化/脚本冒烟（序列化、投影可见性过滤）
- [ ] 开发态冒烟：冷启动 → 开主窗 → 加载样例 → 退出无崩溃

### MVP Done when

用户可在样例板上：**导入/打开全局图与 JSON → 看 Live（或回放）叠加标注 → 改核心参数与状态并保存 → 红绿正确**；配准主路径在典型光照下可跟一段时间；帧率在参考机上主观可接受（目标 ≥15 FPS 有日志或口头记录）。

---

## v0.5

- [ ] YOLO 自动检测种子标注（`vision.detect`；optional 依赖）
- [ ] 检测失败/未安装时主程序仍可启动；入口提示安装 detect extra
- [ ] Fiducial+Affine 与 Local-Global **双路径可切换或简单融合**
- [ ] 4K 下 ROI 模板匹配优化，跟踪链路 **≥15 FPS**（争取 30）有测量记录
- [ ] SQLite 持久化 + 多板切换（JSON 导入导出保留）
- [ ] `doubt`（黄）状态与 UI（已确认不进 MVP，本阶段交付）

### v0.5 Done when

种子检测可跑通并默认 `unchecked`；双 Tracker 可切换；多板 SQLite 可用；性能达标有证据。

---

## v1

- [ ] PyInstaller **onedir 便携版**（Windows x64 优先）；冒烟清单通过
- [ ] （按需）安装包形态【待确认 D7】
- [ ] 拼接管线产品化：重叠提示、错位警告、导入向导
- [ ] XYZ 机台标定矩阵**原型**（可无真机，模拟编码器坐标）
- [ ] `calib.xyz` 与 mm 坐标通路打通文档+演示
- [ ] 手机端可行性评估文档（**非必须同期交付**）
- [ ] 版本号 semver 与单源文件同步；发布清单

### v1 Done when

可分发的 Windows 便携包 + 安装/相机说明；拼接与机台原型可演示；检测仍为可选组件。

---

## 文档阶段门禁（供文档架构自检）

| 阶段 | 文档就绪标志 |
|------|----------------|
| 1 拼图+数据模型 | `DATA_MODEL.md` 已落盘；本清单 MVP 建图项可执行 |
| 2 配准+叠加 | `TECH_SPEC` §2–§4 稳定；Tracker 签名可对齐代码 |
| 3 检测+UX | 气泡≤3、侧栏、状态色、批量核对规则明确 |
| 4 桌面封装 | `TECH_SPEC` §6 发布约定；构建发布计划可引用 |
| 5 XYZ | 坐标解耦与公式在 DATA_MODEL；真机非本期 |

---

## Gaps / Risks

| ID | 风险/缺口 | 影响 | 建议 | 状态 |
|----|-----------|------|------|------|
| R1 | PCB 重复纹理 → 拼接重影 | 全链路标注偏移 | 半自动+外部拼图；禁唯一 Stitcher | 开放 |
| R2 | 4K 全图 matchTemplate 过慢 | FPS 不可用 | ROI ~200×200；金字塔 | 开放 |
| R3 | Fiducial 出视野 | Affine 失败 | 上一矩阵 / Local-Global / UI 丢失 | 开放 |
| R4 | ORB 低纹理 | Homography 失败 | 特征数/AKAZE；提示移动 | 开放 |
| R5 | YOLO 误检漏检 | 人工负担 | 仅种子；批量核对 | 开放 |
| R6 | Z 变焦尺度跳变 | 框漂 | Affine 尺度；后期 Scale(Z) | 开放 |
| R7 | ultralytics/torch 体积 | 分发困难 | 可选依赖；权重外置 | 开放 |
| R8 | mm 原点/轴向未定 | 机台迁移歧义 | **D2 已确认**：允许纯像素 MVP，mm 后补；原点/轴向仍见 **D10** | D2 已确认；D10 待确认 |
| R9 | status 在 core 内 vs 顶层 | 实现分裂 | **D9 已确认**：顶层 `status` 权威；气泡三键不含 status | **已确认** |
| R10 | 样例资产缺失 | 无法演示 | 决策 D8；先合成全局图 | 开放 |
| R11 | 无相机 CI | 冒烟不稳定 | 强制假帧/录像模式；相机策略见 D6 | 开放 |
| R12 | 变换矩阵方向 | 标注飞掉 | **D1 已确认**：全局像素 → 当前帧；代码须按此钉死 | **已确认** |

---

## 待用户确认的决策点（转交小明 / 产品）

1. **D1** — **已确认**（2026-11-09 Asia/Shanghai）：矩阵方向为 **全局像素 → 当前帧像素**。  
2. **D2** — **已确认**（2026-11-09 Asia/Shanghai）：允许 **纯像素 MVP**；`pixel_per_mm` / `absolute_pos_mm` 后补，缺省时 UI 警告。  
3. **D3** — **已确认**（2026-11-09 Asia/Shanghai）：主配准 **LocalGlobal**；**Affine 降级**。  
4. **D4** — **已确认**（2026-11-09 Asia/Shanghai）：跟踪丢失 TTL **0.8 s**；超时 **冻结标注并提示**「跟踪丢失」。  
5. **D5** — **已确认**（2026-11-09 Asia/Shanghai）：`doubt`（黄）放 **v0.5**，**不进 MVP**。  
6. **D6** 【待确认】默认相机索引、目标分辨率（如 3840×2160）及无相机默认回放文件策略。  
7. **D7** 【待确认】发布：仅 onedir 便携 vs 追加安装包；版本单源文件名（`VERSION` vs `pyproject.toml`）。  
8. **D8** 【待确认】首块样例板来源：实拍拼接 / 外部导入 / 合成图；谁提供资产。  
9. **D9** — **已确认**（2026-11-09 Asia/Shanghai）：`status` 为 Component **顶层权威字段**；气泡三键不含 status。  
10. **D10** 【待确认】PCB mm 坐标系原点与轴向（建议 F1 为原点）；是否与机械坐标系预对齐。  
11. **D11** 【待确认】工程 JSON 默认目录（建议 `assets/projects/`）与路径解析根。  
12. **D12** — **已确认**（2026-11-09 Asia/Shanghai）：`core_params` 默认三键 **`name` / `value` / `package`**。  
13. **D13** 【待确认】pydantic 是否列入核心依赖，或仅手写校验 + dev 可选。  
14. **D14** 【待确认】参考机 `DESKTOP-J4I5P0U` 是否作为性能验收唯一基准机。

**仍开放**：D6、D7、D8、D10、D11、D13、D14。  

---

## 角色门禁（本轮 Handoff）

| 角色 | Done when |
|------|-----------|
| 文档架构 | TECH_SPEC + DATA_MODEL + 本清单 + Gaps/决策点已落盘 |
| 视觉工程 | 壳应用 + Capture + 双 Tracker 桩 + 测试计划 |
| 构建发布 | 打包计划 + requirements 模板；**暂不打包** |

更新状态时请注明日期（Asia/Shanghai）与负责人 Bot。
