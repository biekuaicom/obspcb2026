# PCB 显微镜 AR 标注 — 数据模型（DATA_MODEL）

| 字段 | 值 |
|------|-----|
| 版本 | **v0.1.1** |
| 日期 | 2026-11-09（Asia/Shanghai） |
| 状态 | 草稿；**D2/D9/D12**（及矩阵向 **D1**）已确认 2026-11-09 |
| 配套 | `TECH_SPEC.md`、`PROJECT_BRIEF.md` §4 |
| 修订 | 决策 D1/D2/D3/D4/D5/D9/D12 已确认 2026-11-09（Asia/Shanghai） |

---

## 1. 实体总览

| 实体 | 含义 | MVP 载体 | v1 |
|------|------|----------|-----|
| **Board** | 一块 PCB 工程（全局图 + 标定 + 元件集） | 单文件 JSON | `boards` 表 |
| **Component** | 单个元件标注 | `components[]` | `components` 表 |
| **Fiducial** | 定位孔/基准点 | `fiducials[]` | `fiducials` 表 |
| **Session** | 一次核对/跟踪会话元数据 | 可选，可省略 | `sessions` 表 |

---

## 2. 字段说明

### 2.1 Board（工程根）

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `schema_version` | string | 建议 | 如 `"0.1"`；便于迁移 |
| `board_id` | string | 是 | 稳定 ID，如 `DEMO-PCB-001` |
| `name` | string | 否 | 显示名 |
| `global_map_path` | string | 是 | 相对仓库根或工程文件的路径，如 `assets/maps/DEMO-PCB-001.png` |
| `pixel_per_mm` | `{x: number, y: number}` | 条件 | 像素/毫米；**D2 已确认**：可省略跑纯像素 MVP，但 UI 须警告；mm 后补 |
| `fiducials` | Fiducial[] | 建议 | 至少 2 点利于 Affine；0 点则依赖 Local-Global |
| `components` | Component[] | 是 | 可空数组 |
| `meta` | object | 否 | `created_at` / `updated_at`（ISO8601 + 时区）等 |

### 2.2 Component

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `component_id` | string | 是 | 板内唯一，如 `R1` |
| `absolute_pos_mm` | `{x, y}` | 条件 | PCB **物理绝对坐标（mm）**；**D2 已确认**可省略（纯像素 MVP）；原点约定见 §4 / D10 |
| `base_pixel_box` | `[x, y, w, h]` | 是 | **全局图像素**轴对齐框；`x,y` 左上，`w,h` 宽高，单位 px |
| `core_params` | object | 是 | **最多 3 个业务键**（不含嵌套）；画布气泡只读这些 |
| `extended_params` | object | 否 | 侧栏全量；任意键 |
| `status` | enum | 是 | 见 §3；**D9 已确认**：顶层 `status` 为权威字段；与 `core_params.status` 并存时以顶层为准（简报示例提升逻辑见下文） |
| `meta` | object | 否 | `source`: `yolo_seed` \| `manual` \| `import`；`updated_at` |

**`core_params` 归一化（本规格收紧）**

- 简报示例将 `status` 放在 `core_params` 内。为避免气泡占掉 3 键名额，**本规格规定**（**D9/D12 已确认**，2026-11-09 Asia/Shanghai）：
  - **权威字段**：顶层 `status`（画布颜色、批量核对用它）；气泡三键**不含** status。
  - `core_params`：**最多 3 个展示键**；默认键名 **`name` / `value` / `package`**。
  - 若读入旧数据仅有 `core_params.status`，加载时提升到顶层并可选从 core 中移除。

### 2.3 Fiducial

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `id` | string | 是 | 如 `F1` |
| `pixel` | `[x, y]` | 是 | 全局图像素坐标（中心） |
| `mm` | `{x, y}` | 建议 | 物理坐标；与 `pixel_per_mm` 互校 |
| `template_path` | string | 否 | Fiducial 模板图；缺省则从全局图裁 ROI |

### 2.4 Session（v1）

| 字段 | 类型 | 说明 |
|------|------|------|
| `session_id` | string | UUID 或时间戳 |
| `board_id` | string | FK |
| `started_at` / `ended_at` | string | ISO8601 |
| `operator` | string | 可选 |
| `notes` | string | 可选 |
| `stats` | object | 如 `{checked: N, unchecked: M}` 快照 |

MVP 可不落 Session；核对历史靠 JSON 文件版本管理或 `meta.updated_at`。

---

## 3. status 枚举与画布颜色

| status | 含义 | 画布颜色 | MVP |
|--------|------|----------|-----|
| `unchecked` | 待核对 | **红** `#E53935` | 必须 |
| `checked` | 已核对 | **绿** `#43A047` | 必须 |
| `doubt` | 存疑 | **黄** `#FDD835` | **不进 MVP**（**D5 已确认**；放 **v0.5**） |

未知 status → 按 `unchecked` 处理并打日志。

---

## 4. 坐标系约定

### 4.1 `base_pixel_box`（全局图像素）

- 原点：全局图 **左上角**。
- 轴：`x` 向右，`y` 向下（图像惯例）。
- 框：`[x, y, w, h]`，浮点允许；渲染时取整。
- **不**随 Live 帧变化；Live 显示靠 Tracker 矩阵投影。

### 4.2 `absolute_pos_mm`（PCB 物理）

- 单位：毫米。
- 原点与轴向：**D10 【待确认】**；建议 Fiducial `F1` 为原点、`x` 沿板长边、`y` 右手或图像同向——产品需定一条并写进样例板。**D2 已确认**：MVP 可无 mm。
- 用途：后期 XYZ 机台  
  `Screen_Pos ≈ (PCB_Phys_Pos − Machine_Current_Pos) × Scale(Z)`  
  替换纯视觉矩阵；故 **mm 与像素解耦存储**。

### 4.3 `pixel_per_mm`

- `x` / `y` 可不同（非正方形像素或轴校准差）。
- 换算示例：  
  `px = mm * pixel_per_mm`（在原点对齐前提下）；  
  锚点建议用 Fiducial 最小二乘拟合，而非单点外推。

### 4.4 变换方向（与 Tracker 对齐）

- **D1 已确认**（2026-11-09 Asia/Shanghai）：全局像素 → 当前帧像素。
- `LocalGlobalTracker.H`：**全局像素 → 当前帧像素**（对 `base_pixel_box` 四角 `perspectiveTransform`）。
- `PCBAffineTracker.M`：同方向的 2×3（全局 → 当前）；与 OpenCV `estimateAffinePartial2D(src_global, dst_frame)` 一致。
- 若实现时矩阵相反，必须在模块文档字符串与本文件同步改正，禁止 silently 翻转。

---

## 5. `core_params` / `extended_params` 读写边界

| 通道 | 可读 | 可写 | 限制 |
|------|------|------|------|
| 画布气泡 / 内联编辑 | `core_params`（≤3 键） | 仅 `core_params` | 禁止把 extended 键塞进气泡 |
| 右侧栏 | `core` 摘要 + `extended` 全量 + `status` | `extended_params` 全量；`status`；可选同步改 core | — |
| Store API | 全量 | 分字段 patch | 校验见 §8 |

`core_params` 键集合变更（增删键名）属产品配置；**D12 已确认**：MVP 默认三键 **`name` / `value` / `package`**。

---

## 6. JSON 工程清单 — Schema 与示例

### 6.1 完整示例

```json
{
  "schema_version": "0.1",
  "board_id": "DEMO-PCB-001",
  "name": "演示板",
  "global_map_path": "assets/maps/DEMO-PCB-001.png",
  "pixel_per_mm": { "x": 42.0, "y": 42.0 },
  "fiducials": [
    {
      "id": "F1",
      "pixel": [120, 80],
      "mm": { "x": 0.0, "y": 0.0 },
      "template_path": "assets/templates/DEMO-PCB-001_F1.png"
    },
    {
      "id": "F2",
      "pixel": [3800, 90],
      "mm": { "x": 88.0, "y": 0.2 }
    }
  ],
  "components": [
    {
      "component_id": "R1",
      "absolute_pos_mm": { "x": 12.5, "y": 34.2 },
      "base_pixel_box": [100, 150, 60, 30],
      "status": "unchecked",
      "core_params": {
        "name": "R1",
        "value": "10K",
        "package": "0805"
      },
      "extended_params": {
        "tolerance": "1%",
        "supplier": "",
        "sop_note": "注意焊接温度"
      },
      "meta": {
        "source": "yolo_seed",
        "updated_at": "2026-11-09T17:00:00+08:00"
      }
    }
  ],
  "meta": {
    "created_at": "2026-11-09T16:00:00+08:00",
    "updated_at": "2026-11-09T17:00:00+08:00"
  }
}
```

### 6.2 字段约束（校验用）

| 规则 | 说明 |
|------|------|
| `board_id` / `component_id` / fiducial `id` | 非空；板内 unique |
| `base_pixel_box` | 长度 4；`w>0`，`h>0` |
| `core_params` | object；业务键数量 ≤3 |
| `status` | `unchecked` \| `checked` \| `doubt` |
| `global_map_path` | 加载时文件必须存在（相对工程文件目录或仓库根解析顺序【待确认】） |
| 路径 | 正斜杠；相对路径；禁止 `..` 逃逸出工程根（建议） |

---

## 7. 持久化策略

### 7.1 MVP：单板 JSON

- 一板一文件：建议 `assets/projects/<board_id>.json` 或仓库根 `projects/`。【待确认】最终目录。
- 全局图、模板、瓦片走 `assets/`（见 §9）。
- 利于 Git Diff；不支持多板事务。

### 7.2 v1：SQLite 表设计草案

文件建议：`assets/db/pcb_ar.sqlite` 或用户数据目录。

```sql
-- boards
CREATE TABLE boards (
  board_id        TEXT PRIMARY KEY,
  name            TEXT,
  global_map_path TEXT NOT NULL,
  ppm_x           REAL,
  ppm_y           REAL,
  schema_version  TEXT,
  meta_json       TEXT,
  created_at      TEXT,
  updated_at      TEXT
);

-- components
CREATE TABLE components (
  board_id        TEXT NOT NULL REFERENCES boards(board_id),
  component_id    TEXT NOT NULL,
  abs_x_mm        REAL,
  abs_y_mm        REAL,
  box_x           REAL NOT NULL,
  box_y           REAL NOT NULL,
  box_w           REAL NOT NULL,
  box_h           REAL NOT NULL,
  status          TEXT NOT NULL DEFAULT 'unchecked',
  core_json       TEXT NOT NULL,      -- JSON object ≤3 keys
  extended_json   TEXT,               -- JSON object
  meta_json       TEXT,
  PRIMARY KEY (board_id, component_id)
);

-- fiducials
CREATE TABLE fiducials (
  board_id        TEXT NOT NULL REFERENCES boards(board_id),
  fiducial_id     TEXT NOT NULL,
  pixel_x         REAL NOT NULL,
  pixel_y         REAL NOT NULL,
  mm_x            REAL,
  mm_y            REAL,
  template_path   TEXT,
  PRIMARY KEY (board_id, fiducial_id)
);

-- sessions
CREATE TABLE sessions (
  session_id      TEXT PRIMARY KEY,
  board_id        TEXT NOT NULL REFERENCES boards(board_id),
  started_at      TEXT NOT NULL,
  ended_at        TEXT,
  operator        TEXT,
  notes           TEXT,
  stats_json      TEXT
);

CREATE INDEX idx_components_status ON components(board_id, status);
```

导入/导出：提供 JSON ↔ SQLite 互转，避免锁死单一存储。

---

## 8. 校验建议（pydantic 可选）

路径：`src/model/schema.py`

- MVP：可用手写函数 `validate_project(dict) -> list[str]`（错误消息列表）。
- 推荐（不强制）：`pydantic` v2模型；列入 `requirements.txt` 或 `requirements-dev.txt`【待确认】。
- 校验时机：`load` 后、`save` 前、UI 提交 patch 时。
- 失败策略：拒绝写盘；UI 提示首条错误；不静默截断 `core_params`。

---

## 9. 文件路径约定

```
pcb-ar-annotate/
├── assets/
│   ├── maps/              # 全局大图 <board_id>.png|.jpg
│   ├── tiles/<board_id>/  # 半自动瓦片
│   ├── templates/         # Fiducial 模板
│   ├── projects/          # MVP 工程 JSON【待确认】
│   ├── weights/           # YOLO 权重（可选，不进核心包）
│   └── db/                # v1 SQLite
├── src/...
└── docs/...
```

| 约定 | 说明 |
|------|------|
| 大文件 | Git LFS 或外置；简报已写「大文件另议」 |
| 路径分隔 | JSON 内统一 `/` |
| 解析根 | 【待确认】优先：工程 JSON 所在目录 → 其次仓库根 |

---

## 10. 与简报差异（刻意收紧）

1. **`status` 提升为 Component 顶层权威字段**（**D9 已确认**），避免占用 `core_params` 的 3 键名额；兼容读入简报示例时的提升逻辑。  
2. **H/M 为全局→当前帧** 方向（**D1 已确认**）。  
3. `core_params` 默认 **`name` / `value` / `package`**（**D12 已确认**）。  
4. 补充 `schema_version`、Session、SQLite DDL、路径逃逸建议。  
5. **D10 / D11 / D13** 仍【待确认】（mm 原点、工程目录/解析根、pydantic 依赖）。
