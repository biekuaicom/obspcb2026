"""Vision workers.

This slice ships capture plus tracker stubs. The stitch pipeline and YOLO
detection are intentionally absent (no ultralytics).
"""
