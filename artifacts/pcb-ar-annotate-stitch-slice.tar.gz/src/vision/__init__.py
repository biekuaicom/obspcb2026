"""Vision workers.

Capture, tracker stubs, and the semi-automatic tile/global compare live here.
YOLO detection is not part of this tree.
"""
