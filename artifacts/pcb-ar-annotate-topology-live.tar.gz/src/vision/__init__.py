"""Vision workers.

Capture, tracker stubs, still-tile stitch compare, VideoMosaicBuilder,
and the topology live matcher live here. Video mosaic remains an optional
mapping path. Live lock for this slice is binary constellation matching.
YOLO detection is not part of this tree.
"""
