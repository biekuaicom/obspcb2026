"""VideoMosaicBuilder: state machine, skip weak frames, project write-out."""

import json

import cv2
import numpy as np

from model.schema import BoardProject
from vision.mosaic import (
    MAP_SOURCE,
    MappingController,
    MappingState,
    VideoMosaicBuilder,
    make_synthetic_translation_frames,
)


def test_mapping_state_machine_ready_fail_cancel_rescan():
    ready = MappingController()
    assert ready.start_recording() is MappingState.RECORDING
    assert ready.begin_building() is MappingState.BUILDING
    assert ready.mark_ready() is MappingState.MOSAIC_READY
    assert ready.request_rescan() is MappingState.RESCAN
    assert ready.start_recording() is MappingState.RECORDING

    failed = MappingController()
    failed.start_recording()
    assert failed.fail("no lock") is MappingState.FAILED
    assert failed.request_rescan() is MappingState.RESCAN

    cancelled = MappingController()
    cancelled.start_recording()
    assert cancelled.cancel() is MappingState.CANCELLED
    assert cancelled.request_rescan() is MappingState.RESCAN
    cancelled.reset()
    assert cancelled.state is MappingState.IDLE


def test_builder_skips_noise_and_writes_project(tmp_path):
    frames = make_synthetic_translation_frames(count=8, bad_index=3)
    builder = VideoMosaicBuilder(overlap_hint=0.85, motion="feature")
    assert builder.controller.state is MappingState.IDLE
    statuses = [builder.push_frame(frame) for frame in frames]
    assert builder.controller.state is MappingState.RECORDING
    assert statuses[0].accepted is True
    assert statuses[3].accepted is False
    out = tmp_path / "assets" / "maps" / "VIDEO-MAP-001.png"
    result = builder.finalize(out, board_id="VIDEO-MAP-001", repo_root=tmp_path)
    assert result.ok is True
    assert result.state == MappingState.MOSAIC_READY.value
    assert result.frames_total == 8
    assert result.frames_accepted >= 6
    assert result.frames_skipped >= 1
    assert result.canvas_size[0] > frames[0].shape[1]
    assert result.map_source == MAP_SOURCE
    image = cv2.imread(str(out), cv2.IMREAD_COLOR)
    assert image is not None
    assert image.shape[1] == result.canvas_size[0]
    assert image.shape[0] == result.canvas_size[1]
    project = BoardProject.from_json((tmp_path / "assets" / "projects" / "VIDEO-MAP-001.json").read_text())
    assert project.map_source == "video_mosaic"
    assert project.global_map_path.endswith("maps/VIDEO-MAP-001.png")
    mapping = project.meta["mapping"]
    assert mapping["frames_used"] == result.frames_accepted
    assert mapping["canvas_size"] == [result.canvas_size[0], result.canvas_size[1]]
    assert mapping["state"] == "MosaicReady"
    assert mapping["motion"] == "feature"


def test_optical_flow_accepts_translation_and_skips_noise():
    frames = make_synthetic_translation_frames(count=6, bad_index=2)
    builder = VideoMosaicBuilder(overlap_hint=0.85, motion="optical_flow")
    for frame in frames:
        builder.push_frame(frame)
    assert builder.frames[0].accepted is True
    assert builder.frames[2].accepted is False
    assert sum(1 for item in builder.frames if item.accepted) >= 4


def test_cancel_blocks_finalize(tmp_path):
    frame = make_synthetic_translation_frames(count=1, bad_index=None)[0]
    builder = VideoMosaicBuilder()
    builder.push_frame(frame)
    assert builder.cancel() is MappingState.CANCELLED
    result = builder.finalize(tmp_path / "mosaic.png")
    assert result.ok is False
    assert result.state == MappingState.CANCELLED.value
    assert not (tmp_path / "mosaic.png").exists()


def test_reset_returns_to_idle_and_rejects_unrelated_frame():
    frames = make_synthetic_translation_frames(count=2, bad_index=None)
    builder = VideoMosaicBuilder(motion="auto")
    builder.push_frame(frames[0])
    builder.reset()
    assert builder.controller.state is MappingState.IDLE
    assert builder.frames == []
    noise = np.random.default_rng(1).integers(0, 255, size=frames[0].shape, dtype=np.uint8)
    builder.push_frame(frames[0])
    skipped = builder.push_frame(noise)
    assert skipped.accepted is False
    progress = builder.progress()
    payload = json.loads(json.dumps(progress.to_dict()))
    assert payload["frames_total"] == 2
    assert payload["frames_skipped"] == 1
    assert payload["state"] == MappingState.RECORDING.value
