# PCB 显微镜 AR 标注 — 技术规格（TECH_SPEC）

| 字段 | 值 |
|------|-----|
| 版本 | **v0.1.2** |
| 日期 | 2026-11-09（Asia/Shanghai） |
| 状态 | 草稿；**D1–D14 全部已确认** 2026-11-09（Asia/Shanghai） |
| 基线 | `PROJECT_BRIEF.md` v0.1、`HANDOFF.md` |
| 读者 | 视觉工程、构建发布、产品（用户） |
| 修订 | **v0.1.2**：D6/D7/D8/D10/D11/D13/D14 已确认；补「局部瓦片 + 全局对照图导入 / 拼接对照」最小切片（§6.3 / §3.6）。先前 v0.1.1：D1/D2/D3/D4/D5/D9/D12 |

---

## 1. 目标与 MVP 成功标准

### 1.1 目标（对齐简报）

显微镜正上方摄像头驱动的 PCB 元件识别与 AR 风格实时标注：自动种子标注 → 人工核对 → 视口平移/缩放/微旋转时标注框与气泡粘附跟随。本期仅桌面 PC。

### 1.2 MVP 成功标准（可演示即过）

| # | 标准 | 验收方式 |
|---|------|----------|
| M1 | 半自动/离线拼接或导入得到 PCB 全局高清大图 | 打开样例工程可见 `global_map_path` 对应图 |
| M2 | 全局图上种子标注 + 人工核对落库（JSON） | 改状态后写回工程 JSON，重开仍在 |
| M3 | Live 流中局部↔全局配准，视口内标注投影叠加 | 至少一条 Tracker 路径可跑通；可见元件叠加 |
| M4 | 画布内联 ≤3 核心参数；侧栏扩展字段；红/绿状态色 | 双向绑定联调通过 |
| M5 | 800W/4K 下跟踪帧率可接受（目标 ≥15 FPS，争取 30） | 冒烟计时或日志 FPS 计数；参考机优先，各机实测记录（D14） |

---

## 2. 两阶段工作流

### 2.1 阶段 A — 离线/半自动全局建图

| 步骤 | 输入 | 输出 | 失败降级 |
|------|------|------|----------|
| A1 蛇形抓瓦片 | Live 帧 + 键盘触发；相邻视口重叠 **20%–30%** | `assets/samples/<board_id>/tiles/` 或 `assets/tiles/<board_id>/tile_*.png` + 可选位姿元数据 | 重叠不足 → UI 警告，允许强制保存 |
| A2 拼接 | 瓦片集 或 外部拼图软件结果 | `assets/maps/<board_id>.png`（Global Map） | **禁止**把 OpenCV `Stitcher` 全自动作为唯一路径；重影/错位 → 改用 Hugin/PTGui 再导入 |
| A2b 对照验收 | 拼接结果 + 全局对照图 `global_ref.png` | 目视/简单指标对照完整性（见 §6.3） | 对照失败 → 标记缺口，不静默通过 |
| A3 标定尺度 | 已知间距 Fiducial / 尺标 | `pixel_per_mm.{x,y}` | 未知 → **已确认 D2**：允许纯像素 MVP；mm 字段可空但须标警告 |
| A4 种子标注 | Global Map +（可选）YOLO | `components[]`，`status=unchecked`，`source=yolo_seed\|manual` | 无 YOLO → 纯人工框选 |
| A5 人工核对落库 | 用户编辑 | 更新 JSON /（v1）SQLite | 写盘失败 → 提示重试，内存态保留 |

**阶段 A Done when**：工程 JSON 可打开；全局图可显示；至少 1 个元件有 `base_pixel_box` 与 `absolute_pos_mm`（或 mm 待标）。

### 2.2 阶段 B — 在线实时跟随

| 步骤 | 输入 | 输出 | 失败降级 |
|------|------|------|----------|
| B1 取帧 | `VideoCaptureThread` | `frame`（BGR ndarray）+ 时间戳 | 无相机 → 假帧/录像回放模式（D6） |
| B2 配准 | Live Frame + Global Map（或 Fiducial 模板） | 2×3 Affine `M` 或 3×3 Homography `H` + 置信度 | 见 §2.3 |
| B3 投影过滤 | 全局 `base_pixel_box` / mm + 矩阵 | 视口像素框；中心点在视口内才渲染 | 无有效矩阵 → 不画标注或冻结上一帧叠加 |
| B4 叠加渲染 | 可见元件集合 | QGraphics 框/线/气泡更新（**不重建全部 Item**） | 主线程过载 → 跳帧更新标注层 |
| B5 编辑回写 | 气泡/侧栏编辑 | Model 更新 → 持久化 | 校验失败 → 拒绝写回并提示 |

### 2.3 配准失败降级策略

```
优先序（D3/D4 已确认）：
1. LocalGlobalTracker 成功且 inliers 充足 → 用 H（主配准）
2. 否则 PCBAffineTracker 成功 → 用 M（升成 3×3 或统一变换接口；降级路径）
3. 否则沿用上一帧矩阵（TTL = 0.8 s）
4. TTL 过期 → 冻结标注；UI「跟踪丢失」；可提示移到特征更丰富区域
```

| 条件 | 动作 |
|------|------|
| Fiducial 出视野 | Affine 失败 → 切 Local-Global 或冻结上一矩阵 |
| ORB 低纹理 / inliers 不足 | 提高特征数或换 AKAZE（v0.5）；提示用户移动视口 |
| Z 变焦尺度突变 | Affine 尺度项吸收；异常跳变 → 丢弃本帧矩阵 |

---

## 3. 模块接口草案

路径对齐简报第 5 节。签名级约定；视觉工程首轮可先桩后实。

### 3.1 `vision.capture` — `VideoCaptureThread`

路径：`src/vision/capture.py`

```python
from PyQt6.QtCore import QThread, pyqtSignal
import numpy as np

class VideoCaptureThread(QThread):
    """OpenCV 采集线程；禁止在主线程做 read()。"""
    frame_ready = pyqtSignal(object, float)  # (np.ndarray BGR, timestamp_s)
    error = pyqtSignal(str)
    stopped = pyqtSignal()

    def __init__(self, source: int | str = 0, width: int | None = None,
                 height: int | None = None, parent=None): ...
    def run(self) -> None: ...
    def stop(self, wait_ms: int = 2000) -> None:
        """置位退出标志，release capture，wait；可重复调用。"""
    def set_source(self, source: int | str) -> None:
        """热切换源；下一循环生效。暂停信号策略实现自定，须文档化。"""
```

约定（**D6 已确认**）：

- 默认 `source=0`（相机索引 0）；可选传入索引或分辨率。
- 优先请求接近 **4K**（如 3840×2160）；失败则使用设备实际分辨率并记日志。
- 无相机时 `source` 可为视频路径或 `"synthetic"`；**必须**可回放/假帧降级，否则 CI 与无硬件演示失败。
- 发出的 `ndarray` 视为只读快照（调用方拷贝再改）。

### 3.2 `vision.affine_tracker` — `PCBAffineTracker`

路径：`src/vision/affine_tracker.py`

```python
from dataclasses import dataclass
import numpy as np

@dataclass
class AffineResult:
    M: np.ndarray          # 2x3 float64；全局→当前帧（D1 已确认；见 DATA_MODEL）
    confidence: float      # 0..1 或 inlier 比例
    ok: bool
    message: str = ""

class PCBAffineTracker:
    """Fiducial 模板匹配 + estimateAffinePartial2D（平移+旋转+等比缩放）。"""

    def __init__(self, roi_size: tuple[int, int] = (200, 200)): ...
    def set_templates(self, templates: list[dict]) -> None:
        """[{id, image|path, global_pixel:(x,y)}, ...]"""
    def reset(self) -> None: ...
    def track(self, frame_bgr: np.ndarray) -> AffineResult:
        """ROI 窗口匹配；初始化记录孔位邻域，后续仅在 ~roi_size 内搜。"""
```

### 3.3 `vision.local_global` — `LocalGlobalTracker`

路径：`src/vision/local_global.py`

```python
@dataclass
class HomographyResult:
    H: np.ndarray          # 3x3；全局像素 → 当前帧像素（D1 已确认）
    inliers: int
    confidence: float
    ok: bool
    message: str = ""

class LocalGlobalTracker:
    """全局图预提取 ORB；Live KNN + Lowe(0.75) + RANSAC Homography。"""

    def __init__(self, n_features: int = 5000, ratio: float = 0.75,
                 ransac_thresh: float = 3.0): ...
    def set_global_map(self, global_bgr: np.ndarray) -> None:
        """预计算全局描述子；换板时调用。"""
    def track(self, frame_bgr: np.ndarray) -> HomographyResult: ...
    def project_boxes(self, boxes_xywh: list[tuple[float, float, float, float]],
                      H: np.ndarray) -> list[np.ndarray]:
        """perspectiveTransform 四角 → 当前帧多边形/外接矩形。"""
```

### 3.4 `model.store` / `model.schema`

路径：`src/model/store.py`、`src/model/schema.py`

```python
# schema.py — 运行时手写最小校验（D13）；pydantic 仅 requirements-dev 可选
class BoardProject: ...          # 见 DATA_MODEL.md
class Component: ...
class Fiducial: ...
STATUS_COLORS = {"unchecked": "#E53935", "checked": "#43A047", "doubt": "#FDD835"}

# store.py
class ProjectStore:
    def load(self, path: str) -> BoardProject: ...
    def save(self, project: BoardProject, path: str | None = None) -> None: ...
    def update_component(self, component_id: str, *, core: dict | None = None,
                         extended: dict | None = None, status: str | None = None) -> None: ...
    def list_visible(self, viewport_polygon, transform) -> list[Component]: ...
```

读写边界：**画布只读写 `core_params`（默认键 `name`/`value`/`package`，D12）**；**侧栏读写 `extended_params` 全量**；**顶层 `status` 权威**（D9），两边都可改，以 Model 为单一真相；气泡不含 status。

路径解析（**D11 已确认**）：默认工程目录 `assets/projects/`；JSON 内相对路径**相对工程目录**解析。

### 3.5 UI — `PCBCanvasView` / `annotation_items` / `sidebar`

路径：`src/app/ui/canvas.py`、`annotation_items.py`、`sidebar.py`、`main_window.py`

```python
class PCBCanvasView(QGraphicsView):
    component_selected = pyqtSignal(str)       # component_id
    core_param_edited = pyqtSignal(str, dict)  # id, partial core_params

    def set_video_frame(self, bgr: np.ndarray) -> None: ...
    def set_annotations(self, items: list[AnnotationViewModel]) -> None: ...
    def set_tracking_ok(self, ok: bool) -> None: ...

# annotation_items.py
class AnnotationRectItem(QGraphicsRectItem): ...
class AnnotationLeaderLine(QGraphicsLineItem): ...
class AnnotationBubble(QGraphicsTextItem):
    """最多展示 3 个核心参数；点击进入内联编辑。"""

# sidebar.py
class SidebarPanel(QWidget):
    extended_edited = pyqtSignal(str, dict)
    status_changed = pyqtSignal(str, str)      # id, status
    batch_set_status = pyqtSignal(list, str)   # ids, status
```

**双向绑定约定**

1. Model 变更 → 发信号/回调 → Canvas 与 Sidebar **同时**刷新同一 `component_id`。
2. Canvas 编辑 `core_params` → Store → Sidebar 只读区同步；不直接改 Sidebar 控件内部状态绕过 Store。
3. Sidebar 编辑 `extended_params` → Store；Canvas 气泡**不**显示扩展字段。
4. 选中态：Canvas 点击 ↔ Sidebar 高亮同一元件；取消选中双方清空。
5. 颜色：`unchecked`=红、`checked`=绿；`doubt`=黄（**D5 已确认**：不进 MVP，放 v0.5）。

分层（简报）：底层视频 `QGraphicsPixmapItem` → 中层框/线 → 顶层气泡。

### 3.6 `vision.stitch` / 样例导入 — 局部瓦片 + 全局对照（本轮下一刀）

路径建议：`src/vision/stitch.py`、`src/model/sample_import.py`（名可调整，签名级约定如下）。

```python
from dataclasses import dataclass
from pathlib import Path

@dataclass
class TileSet:
    board_id: str
    tile_paths: list[Path]          # 有序或无序局部瓦片
    global_ref_path: Path | None    # 全局对照图 global_ref.png
    manifest_path: Path | None      # 可选 tiles_manifest.json

@dataclass
class StitchResult:
    ok: bool
    mosaic_path: Path | None        # 半自动/占位拼接输出
    message: str = ""
    coverage_hint: float | None = None  # 可选：相对对照图的粗覆盖率 0..1

class SampleAssetImporter:
    """从解压目录或已落盘 assets/samples/<board_id>/ 导入瓦片集 + 全局对照。"""

    def import_board_dir(self, board_dir: Path, board_id: str) -> TileSet:
        """约定：tiles/ 下局部图；根下 global_ref.png（或 maps 对照）。写/更新 manifest。"""

    def ensure_project_stub(self, board_id: str, tile_set: TileSet) -> Path:
        """在 assets/projects/<board_id>.json 落盘最小工程 stub（相对路径，D11）。"""

class SemiAutoStitchPipeline:
    """半自动拼接管线；MVP 可为占位（拷贝/简单拼接），禁止唯一依赖 Stitcher。"""

    def run(self, tile_set: TileSet, out_mosaic: Path) -> StitchResult: ...

    def compare_to_ref(self, mosaic: Path, global_ref: Path) -> dict:
        """对照验收：至少返回 {ok, notes, ...}；可用尺寸比、可选粗 overlap/覆盖提示。
        Done 不要求精密配准分数，要求能加载并对目视/简单指标给出结论。"""
```

**目录约定（D8 / D11）**

```
assets/
├── samples/<board_id>/
│   ├── tiles/                 # 局部瓦片（从 zip 导入）
│   ├── global_ref.png         # 用户提供的全局整图对照
│   └── tiles_manifest.json    # 可选：瓦片清单与导入元数据
├── maps/<board_id>.png        # 拼接管线产出的全局图（可先占位）
└── projects/<board_id>.json   # 工程 JSON；相对路径相对工程目录解析
```

**源资产（D8）**：用户本机 `E:\局部图片.zip`（十余张局部 + 一张全局整图）。文档预留导入流程；样例 zip **可后进仓**，不阻塞接口与目录约定落地。建议解压后落入 `assets/samples/<board_id>/`。

**Done when（本切片）**：

1. 能加载瓦片集 + 全局对照图（路径与 schema/manifest 落盘）；  
2. 能跑或占位半自动拼接管线，产出/引用 mosaic；  
3. 能目视或简单指标对照 mosaic vs `global_ref` 的完整性；  
4. 工程 JSON 使用相对路径，解析根为工程目录（`assets/projects/`）。

---

## 4. 性能预算

| 项 | 预算 / 约定 |
|----|-------------|
| 相机 | ~800 万像素；优先请求接近 4K（3840×2160）；失败用实际分辨率（D6） |
| 目标帧率 | 跟踪链路 **≥15 FPS**，争取 **30 FPS** |
| 基准机 | **`DESKTOP-J4I5P0U` 优先参考**；**不**唯一卡死一台机；各机实测须记录（D14） |
| 模板匹配 | **ROI 窗口**（默认 ~200×200）；可金字塔粗→细 |
| ORB | 全局描述子预计算一次；Live 侧限特征数 |
| 线程 | Capture + 配准在 **Worker**；主线程只更新 pixmap / 可见 GraphicsItem |
| 标注更新 | **仅可见项**；禁止每帧销毁重建全部 Item |
| 降载 | 配准跟不上则跳帧配准、仍显示上一矩阵（带丢失计时） |

Worker → UI：经 Qt 信号传递；大数组注意拷贝成本（零拷贝策略实现自定，须文档化）。

---

## 5. 文档阶段 1–5 验收标准（对齐简报 §6）

| 阶段 | 范围 | 验收标准（文档/实现 readiness） |
|------|------|--------------------------------|
| **1** 全局拼图 + 数据模型 | 瓦片规范、拼接质量、JSON/SQLite Schema | 本仓库 `DATA_MODEL.md` 定稿；瓦片重叠与导入路径写清；样例工程 JSON 字段齐全可校验；§6.3 切片可执行 |
| **2** 局部–全局配准 + 叠加 | Tracker API、失败降级、可见性裁剪、性能 | 本文 §2–§4；两条 Tracker 签名稳定；降级与「跟踪丢失」行为可测 |
| **3** 自动检测 + 核对 UX | YOLO 种子、气泡≤3、侧栏、状态色、批量核对 | UX 规则写入本文 §3.5；检测为可选依赖；默认 `unchecked` |
| **4** 桌面封装 | PyInstaller、依赖分层、安装与相机 | 本文 §6 发布约定；`ultralytics`/`torch` 不进核心包；冒烟清单可执行 |
| **5** XYZ 机台标定 | 物理坐标解耦、编码器、Scale(Z)、串口草案 | 占位模块 `src/calib/xyz.py`；公式与坐标约定在 DATA_MODEL；**本期不实现真机** |

---

## 6. 发布约定（D6 / D7 / D14 已确认）

> 供「构建发布」对齐；在可运行代码 + 冒烟通过前**不执行正式打包**。

| 项 | 约定 |
|----|------|
| 平台 | **优先 Windows x64**；参考机 `DESKTOP-J4I5P0U`（优先，非唯一）；Linux 作构建/冒烟次要 |
| 产物 | **PyInstaller onedir 便携版为先**；规划后续安装包与**带版本号**的更新安装路径（**不要无版本号**）（D7） |
| 版本 | **semver**；**`VERSION` 文件单源**；构建时同步进包内元数据 / 关于对话框 |
| 核心依赖 | `opencv-python`、`PyQt6`、`numpy`；运行时**不含** pydantic（D13） |
| 可选 / dev | `ultralytics` + `torch` 不进核心包；`pydantic` 仅 `requirements-dev`（可选） |
| 资源外置 | 全局图、Fiducial 模板、权重、样例瓦片放 `assets/` 或用户数据目录 |

### 6.1 冒烟验收项（打包后 / 开发运行均适用）

1. 冷启动无未捕获异常  
2. 打开主窗口（视频区 + 侧栏 Dock 可见）  
3. 加载样例工程 JSON + 全局图（或 global_ref / mosaic）  
4. **无相机**：synthetic 或录像回放可出帧（D6）  
5. **有相机**（可选）：索引 0 打开；近 4K 请求失败时仍能用实际分辨率  
6. 正常退出无崩溃（Capture `stop` 干净）  
7. 性能笔记：记录机名与 FPS；参考机优先达 **≥15 FPS**（D14）

### 6.2 运行时依赖与已知限制

| 依赖/限制 | 说明 |
|-----------|------|
| 相机 | Windows：DirectShow/MediaFoundation；默认索引 0；优先近 4K，失败用实际分辨率（D6） |
| 无相机 | **必须**支持录像/合成帧，否则 CI 与无硬件演示失败（D6） |
| OpenCV / PyQt6 打包 | 隐藏导入 Qt 平台插件、opencv DLL 路径为已知坑（见构建发布计划） |
| 检测功能 | 未装 optional 时入口灰显或提示，**不得**因缺 torch 导致主程序无法启动 |
| 大图内存 | 超大 Global Map 可能 OOM；实现可限制最大边长或使用金字塔（实现自定，须文档化） |
| 版本更新 | 便携 onedir 以版本目录/VERSION 区分；安装包更新路径后续规划（D7） |

### 6.3 样例资产与「局部瓦片 + 全局对照」导入约定（D8）

| 项 | 约定 |
|----|------|
| 源 | 用户本机 **`E:\局部图片.zip`**（十余张局部 + 一张全局整图）；**可后进仓**，不阻塞目录/接口落地 |
| 落盘 | 解压/导入至 `assets/samples/<board_id>/tiles/` + `global_ref.png` |
| 工程 | `assets/projects/<board_id>.json`；相对路径相对工程目录解析（D11） |
| 对照 | 拼接管线产出（或占位 mosaic）vs `global_ref`：目视正确完整 + 可选简单指标 |
| 接口 | 见 §3.6 `SampleAssetImporter` / `SemiAutoStitchPipeline` |

预留 UI/CLI 入口（如「导入样例板」）：选 zip 或已解压目录 → 写 samples 树 + 工程 stub → 可选跑 stitch → 打开对照视图。

---

## 7. Gaps / Risks 与建议决策

### 7.1 简报 §8 风险（纳入规格）

| 风险 | 对策（规格层） |
|------|----------------|
| 重复纹理拼接误匹配 | 半自动网格；外部拼图导入；禁止唯一依赖 Stitcher；对照 global_ref |
| 4K 全图 matchTemplate 过慢 | ROI ~200×200；粗精匹配 |
| Fiducial 出视野 | 上一帧矩阵 / 切 Local-Global / UI 丢失 |
| ORB 低纹理 | 特征数/AKAZE；依赖 Fiducial；提示移动 |
| YOLO 误检漏检 | 仅种子；默认 unchecked；批量通过/驳回 |
| Z 变焦尺度 | Affine 等比；后期 Scale(Z) |
| 打包体积 | ultralytics 可选；权重外置 |

### 7.2 决策状态摘要

见 `MILESTONES.md`「待用户确认的决策点」完整列表。**D1–D14 全部已确认**（2026-11-09 Asia/Shanghai）。摘要：

- **D1** — 全局像素 → 当前帧像素  
- **D2** — 允许纯像素 MVP；mm 后补  
- **D3** — 主配准 LocalGlobal；Affine 降级  
- **D4** — TTL 0.8 s；超时冻结并提示  
- **D5** — `doubt` 放 v0.5，不进 MVP  
- **D6** — 默认相机索引 0；近 4K 优先；无相机 synthetic/录像  
- **D7** — VERSION 单源 + onedir 便携为先；规划安装包/更新路径  
- **D8** — 样例 `E:\局部图片.zip`；预留导入；`assets/samples/`  
- **D9** — 顶层 `status` 权威；气泡不含 status  
- **D10** — 长边横向(x)/短边竖向(y)；F1 原点建议；图像同向；暂不预对齐机械系  
- **D11** — `assets/projects/`；路径相对工程目录解析  
- **D12** — `core_params` = `name` / `value` / `package`  
- **D13** — 运行时手写校验；pydantic 仅 requirements-dev  
- **D14** — DESKTOP-J4I5P0U 优先参考；≥15 FPS 记各机实测  

**仍开放**：无。

---

## 8. 非目标（本期不做）

- 手机端正式产品化  
- 完整 6DoF / SLAM / 完整透视畸变建模  
- 外部 ERP/MES/历史 BOM 对接  
- 生产级 SMT 闭环控制  
- 以 OpenCV `Stitcher` 全自动作为唯一建图路径  
- 核心安装包捆绑 torch/ultralytics 与检测权重  
- 无版本号的发布产物（D7 禁止）  

---

## 9. 本轮协作提示

- **视觉工程空壳已完成**；**本轮下一刀**：§3.6 / §6.3「局部瓦片 + 全局对照图导入 / 拼接对照」最小切片（见 `MILESTONES.md` 对应勾选项）。  
- **构建发布**：按 §6（VERSION + onedir）补打包计划与 requirements 模板；Gate 后打包。  
- 规格变更：先改本文档与 DATA_MODEL，再通知视觉/构建对齐。
