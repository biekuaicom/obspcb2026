# PCB 显微镜 AR 标注 — 里程碑检查清单（MILESTONES）

| 字段 | 值 |
|------|-----|
| 版本 | **v0.1.2** |
| 日期 | 2026-11-09（Asia/Shanghai） |
| 对齐 | `PROJECT_BRIEF.md` §7、`HANDOFF.md` |
| 用法 | 勾选 `[x]`；每阶段满足 **Done when** 再进入下一阶段 |
| 修订 | **v0.1.2**：决策 **D6/D7/D8/D10/D11/D13/D14** 已确认 2026-11-09（Asia/Shanghai）；**D1–D14 全部已确认**。先前 v0.1.1：D1/D2/D3/D4/D5/D9/D12 |

---

## 本轮视觉工程应先实现（对齐 HANDOFF §2）

> **现在先做这一刀，不等全部规格拍板。**

- [ ] 按简报脚手架：`src/app`、`src/vision`、`src/model`、`tests/`（及 `calib` 占位）
- [ ] 实现 **`VideoCaptureThread`**（OpenCV → 信号发帧；可安全 `stop`；无相机可用假帧/视频）
- [ ] **PyQt6 主窗口壳**：`QGraphicsScene` 视频底图 + 空标注层 + 右侧 `QDockWidget` 占位
- [ ] **`PCBAffineTracker` / `LocalGlobalTracker` 桩**（类签名、文档字符串、空实现或假单位矩阵）
- [ ] **测试计划**：`tests/README.md` 或 `docs/TEST_PLAN.md`（配准成功/失败、投影可见性、JSON 序列化冒烟）
- [ ] 可运行入口：`python -m app.main`（或等价）打开空壳

**本轮视觉 Done when**（HANDOFF）：可启动壳应用 + Capture 线程 + 两个 Tracker 桩 + 测试计划。  
TECH_SPEC 定稿后做一次接口对齐（命名/信号/矩阵方向）。

**一句话切片**：脚手架 + Capture 线程 + 主窗口壳 + 双 Tracker 桩 + 测试计划。

> **空壳状态**：视觉工程本轮空壳已完成；下一切换到「局部瓦片 + 全局对照」切片。

---

## 本轮下一刀：局部瓦片 + 全局对照图导入 / 拼接对照

对齐 `TECH_SPEC.md` §3.6、§6.3 与 `DATA_MODEL.md` §2.5 / §9（D8 / D11）。

### 可勾选任务

- [ ] 目录约定落地：`assets/samples/<board_id>/tiles/`、`global_ref.png`（及可选 `tiles_manifest.json`）；工程 JSON 在 `assets/projects/`
- [ ] 路径解析：相对路径相对**工程目录**解析（D11）；禁止错误逃逸
- [ ] `SampleAssetImporter`（或等价）：导入瓦片清单 + 导入/引用全局对照图；写 manifest / 工程 stub
- [ ] 源资产流程预留：用户本机 `E:\局部图片.zip`（十余张局部 + 一张全局整图）——文档与入口预留；样例 zip **可后进仓**
- [ ] `SemiAutoStitchPipeline`（可为占位）：加载瓦片集 → 产出/引用 mosaic → 与 `global_ref` 对照
- [ ] 对照验收：目视正确完整，或简单指标（如尺寸比 / 粗覆盖提示）；对照失败不静默通过
- [ ] 路径与 schema 落盘：工程 JSON 含 `global_map_path` / 可选 `global_ref_path`；与 DATA_MODEL 一致
- [ ] 冒烟：无真实 zip 时可用空/合成 tiles + 假 global_ref 跑通导入与对照桩

### Done when

1. 能加载瓦片集 + 全局对照图；  
2. 能跑或占位半自动拼接管线；  
3. 能目视或简单指标对照 mosaic vs `global_ref` 的完整性；  
4. 路径与 schema 落盘（`assets/projects/` + samples 树，D11）。

**一句话切片**：样例目录 + 导入瓦片/全局对照 + 占位拼接 + 对照验收 + 工程 stub。

---

## MVP（桌面可演示）

对齐简报 §7 MVP，细化验收点。

### 建图与数据

- [ ] 半自动网格抓图 **或** 全局图导入（外部 Hugin/PTGui 结果可导入即可）
- [ ] 瓦片重叠提示（目标 20%–30%）；错位不静默吞掉
- [ ] JSON 数据模型落地（见 `DATA_MODEL.md`）+ 至少一块样例板工程
- [ ] 预留样例资产导入流程：用户本机 `E:\局部图片.zip`（十余张局部 + 一张全局整图）→ 工程侧可导入并对照拼接结果（见 D8 / TECH_SPEC §6.3）
- [ ] `ProjectStore.load/save`；重开工程状态保持；默认工程目录 `assets/projects/`（D11）

### 采集与 UI 壳

- [ ] `VideoCaptureThread` + QGraphics 视频底图
- [ ] 主窗口：中央 Canvas + 右侧 Dock；菜单/工具栏可极简
- [ ] 无相机降级路径可用（synthetic / 录像回放，D6）
- [ ] 默认相机索引 0；优先请求接近 4K，失败用实际分辨率（D6）

### 配准与叠加

- [ ] **主路径** `LocalGlobalTracker` 真实现可跑通；`PCBAffineTracker` 作降级（可为增强桩）
- [ ] 全局标注投影到当前视口；中心不在视口内不渲染
- [ ] 跟踪失败降级：沿用上一帧矩阵，**TTL = 0.8 s**；超时冻结标注并提示「跟踪丢失」
- [ ] 状态色：未核对 **红** / 已核对 **绿**（`doubt`/黄 **不进 MVP**，见 v0.5）

### 编辑与绑定

- [ ] 画布内联编辑 ≤3 个 `core_params`
- [ ] 侧栏编辑 `extended_params`；与画布选中双向联动
- [ ] 改 status 即时变色并写回 JSON

### 质量

- [ ] 基础测试计划文档 + 至少若干自动化/脚本冒烟（序列化、投影可见性过滤）
- [ ] 开发态冒烟：冷启动 → 开主窗 → 加载样例 → 退出无崩溃
- [ ] 性能：参考机 `DESKTOP-J4I5P0U` 优先；验收目标 **≥15 FPS** 并记录各机实测（D14）

### MVP Done when

用户可在样例板上：**导入/打开全局图与 JSON → 看 Live（或回放）叠加标注 → 改核心参数与状态并保存 → 红绿正确**；配准主路径在典型光照下可跟一段时间；帧率在参考机上主观可接受（目标 ≥15 FPS 有日志记录；各机实测记入发布/冒烟笔记）。

---

## v0.5

- [ ] YOLO 自动检测种子标注（`vision.detect`；optional 依赖）
- [ ] 检测失败/未安装时主程序仍可启动；入口提示安装 detect extra
- [ ] Fiducial+Affine 与 Local-Global **双路径可切换或简单融合**
- [ ] 4K 下 ROI 模板匹配优化，跟踪链路 **≥15 FPS**（争取 30）有测量记录
- [ ] SQLite 持久化 + 多板切换（JSON 导入导出保留）
- [ ] `doubt`（黄）状态与 UI（已确认不进 MVP，本阶段交付）

### v0.5 Done when

种子检测可跑通并默认 `unchecked`；双 Tracker 可切换；多板 SQLite 可用；性能达标有证据。

---

## v1

- [ ] **VERSION 单源** + PyInstaller **onedir 便携版**（Windows x64 优先）；冒烟清单通过（D7）
- [ ] 规划后续安装包 / 带版本号的更新安装路径（不要无版本号）（D7）
- [ ] 拼接管线产品化：重叠提示、错位警告、导入向导（含 D8 样例 zip 导入）
- [ ] XYZ 机台标定矩阵**原型**（可无真机，模拟编码器坐标）
- [ ] `calib.xyz` 与 mm 坐标通路打通文档+演示
- [ ] 手机端可行性评估文档（**非必须同期交付**）
- [ ] 版本号 semver 与 `VERSION` 单源文件同步；发布清单

### v1 Done when

可分发的 Windows 便携包（带版本号）+ 安装/相机说明；拼接与机台原型可演示；检测仍为可选组件。

---

## 文档阶段门禁（供文档架构自检）

| 阶段 | 文档就绪标志 |
|------|----------------|
| 1 拼图+数据模型 | `DATA_MODEL.md` 已落盘；本清单 MVP 建图项可执行 |
| 2 配准+叠加 | `TECH_SPEC` §2–§4 稳定；Tracker 签名可对齐代码 |
| 3 检测+UX | 气泡≤3、侧栏、状态色、批量核对规则明确 |
| 4 桌面封装 | `TECH_SPEC` §6 发布约定；构建发布计划可引用 |
| 5 XYZ | 坐标解耦与公式在 DATA_MODEL；真机非本期 |

---

## Gaps / Risks

| ID | 风险/缺口 | 影响 | 建议 | 状态 |
|----|-----------|------|------|------|
| R1 | PCB 重复纹理 → 拼接重影 | 全链路标注偏移 | 半自动+外部拼图；禁唯一 Stitcher | 开放 |
| R2 | 4K 全图 matchTemplate 过慢 | FPS 不可用 | ROI ~200×200；金字塔 | 开放 |
| R3 | Fiducial 出视野 | Affine 失败 | 上一矩阵 / Local-Global / UI 丢失 | 开放 |
| R4 | ORB 低纹理 | Homography 失败 | 特征数/AKAZE；提示移动 | 开放 |
| R5 | YOLO 误检漏检 | 人工负担 | 仅种子；批量核对 | 开放 |
| R6 | Z 变焦尺度跳变 | 框漂 | Affine 尺度；后期 Scale(Z) | 开放 |
| R7 | ultralytics/torch 体积 | 分发困难 | 可选依赖；权重外置 | 开放 |
| R8 | mm 原点/轴向 | 机台迁移歧义 | **D2+D10 已确认**：纯像素 MVP；长边横向(x)/短边竖向(y)；原点建议 F1；图像同向 x右 y下；暂不强制预对齐机械系 | **已确认** |
| R9 | status 在 core 内 vs 顶层 | 实现分裂 | **D9 已确认**：顶层 `status` 权威；气泡三键不含 status | **已确认** |
| R10 | 样例资产 | 无法演示 | **D8 已确认**：用户本机 `E:\局部图片.zip`；工程预留导入；可放 `assets/samples/` | **已确认**（资产待导入） |
| R11 | 无相机 CI | 冒烟不稳定 | **D6 已确认**：强制 synthetic/录像回放；默认相机索引 0，优先近 4K | **已确认** |
| R12 | 变换矩阵方向 | 标注飞掉 | **D1 已确认**：全局像素 → 当前帧；代码须按此钉死 | **已确认** |
| R13 | 发布无版本号 | 更新安装困难 | **D7 已确认**：VERSION 单源 + onedir 便携为先；规划安装包/更新路径 | **已确认** |
| R14 | 校验依赖膨胀 | 运行包变重 | **D13 已确认**：运行时手写最小校验；pydantic 仅 requirements-dev | **已确认** |
| R15 | 性能基准机唯一卡死 | 他机无法验收 | **D14 已确认**：DESKTOP-J4I5P0U 优先参考；≥15 FPS 并记各机实测 | **已确认** |

---

## 待用户确认的决策点（转交小明 / 产品）

1. **D1** — **已确认**（2026-11-09 Asia/Shanghai）：矩阵方向为 **全局像素 → 当前帧像素**。  
2. **D2** — **已确认**（2026-11-09 Asia/Shanghai）：允许 **纯像素 MVP**；`pixel_per_mm` / `absolute_pos_mm` 后补，缺省时 UI 警告。  
3. **D3** — **已确认**（2026-11-09 Asia/Shanghai）：主配准 **LocalGlobal**；**Affine 降级**。  
4. **D4** — **已确认**（2026-11-09 Asia/Shanghai）：跟踪丢失 TTL **0.8 s**；超时 **冻结标注并提示**「跟踪丢失」。  
5. **D5** — **已确认**（2026-11-09 Asia/Shanghai）：`doubt`（黄）放 **v0.5**，**不进 MVP**。  
6. **D6** — **已确认**（2026-11-09 Asia/Shanghai）：默认相机 + 可选相机索引/分辨率；无相机必须可回放/假帧降级。推荐：默认索引 **0**，优先请求接近 **4K**，失败用实际分辨率；无相机 **synthetic / 录像**。  
7. **D7** — **已确认**（2026-11-09 Asia/Shanghai）：要有版本号；**VERSION 单源** + **onedir 便携为先**；规划后续安装包/带版本更新安装路径（不要无版本号）。  
8. **D8** — **已确认**（2026-11-09 Asia/Shanghai）：用户提供样例本机 `E:\局部图片.zip`（十余张局部 + 一张全局整图），用于拼接结果对照全局图；工程侧预留导入该资产流程（可放 `assets/samples/`）。  
9. **D9** — **已确认**（2026-11-09 Asia/Shanghai）：`status` 为 Component **顶层权威字段**；气泡三键不含 status。  
10. **D10** — **已确认**（2026-11-09 Asia/Shanghai）：长边为横向(x)、短边为竖向(y)；板按「文本/芯片型号多数从左到右可读」放置；个别元件朝向不同属正常。原点仍建议 **F1**；轴向与图像同向（x右 y下）并与「长边横向」一致。暂不强制预对齐机械系。  
11. **D11** — **已确认**（2026-11-09 Asia/Shanghai）：相对路径 + 默认工程目录 **`assets/projects/`**，路径相对工程目录解析。  
12. **D12** — **已确认**（2026-11-09 Asia/Shanghai）：`core_params` 默认三键 **`name` / `value` / `package`**。  
13. **D13** — **已确认**（2026-11-09 Asia/Shanghai）：运行时用手写最小校验；**pydantic 仅放 `requirements-dev`（可选）**，不进核心运行依赖。  
14. **D14** — **已确认**（2026-11-09 Asia/Shanghai）：不唯一卡死一台机；**`DESKTOP-J4I5P0U` 作优先参考**；验收目标 **≥15 FPS** 并记录各机实测。

**仍开放**：无（D1–D14 全部已确认）。

---

## 角色门禁（本轮 Handoff）

| 角色 | Done when |
|------|-----------|
| 文档架构 | TECH_SPEC + DATA_MODEL + 本清单 + Gaps/决策点已落盘 |
| 视觉工程 | 壳应用 + Capture + 双 Tracker 桩 + 测试计划 |
| 构建发布 | 打包计划 + requirements 模板；**暂不打包** |

更新状态时请注明日期（Asia/Shanghai）与负责人 Bot。
