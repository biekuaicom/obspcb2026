# HANDOFF — 三角色首批任务

> 共同基线：`/workspace/pcb-ar-annotate/PROJECT_BRIEF.md`  
> 仓库根：`/workspace/pcb-ar-annotate/`  
> 原则：文档可先行；视觉可先按简报脚手架；**构建发布在有可运行代码前只做计划与依赖模板，不打包。**

---

## 1. 文档架构 Bot

**角色定位**：需求/架构文档、数据模型、里程碑与风险；长期复用于后续开发任务的规格沉淀。

### 首批任务

1. 通读 `PROJECT_BRIEF.md`，标出模糊点与需产品确认项（写入 gaps 小节）。
2. 产出 **`docs/TECH_SPEC.md`**，覆盖：
   - 两阶段工作流（全局拼图 → 局部–全局实时配准）
   - 模块接口草案（`VideoCaptureThread`、`PCBAffineTracker`、`LocalGlobalTracker`、UI 绑定）
   - 性能预算（4K / ROI 匹配 / 目标 FPS）
   - 文档阶段 1–5 的验收标准
3. 产出 **`docs/DATA_MODEL.md`**：JSON Schema 说明、状态枚举、fiducials/boards 结构、SQLite 演进表设计草案。
4. 产出 **里程碑检查清单**（MVP / v0.5 / v1），与简报第 7 节对齐并可勾选。
5. 单独列出 **Gaps / Risks**（拼接误匹配、跟踪丢失、可选 YOLO 体积等）及建议决策。

### 交付路径

- `/workspace/pcb-ar-annotate/docs/TECH_SPEC.md`
- `/workspace/pcb-ar-annotate/docs/DATA_MODEL.md`
- （可选）`/workspace/pcb-ar-annotate/docs/MILESTONES.md`

### 协作约定

- 规格变更先改文档，再通知视觉工程与构建发布。
- 不阻塞视觉：脚手架可先按 `PROJECT_BRIEF.md` 开工；接口以 TECH_SPEC 定稿后对齐。

---

## 2. 视觉工程 Bot

**角色定位**：PyQt6 + OpenCV 实现、算法桩与测试；长期复用于视觉/桌面功能迭代。

### 首批任务

1. 按简报脚手架项目结构（`src/app`、`src/vision`、`src/model`、`tests`）。
2. 实现 **`VideoCaptureThread`**（OpenCV 采集 → 信号发帧；可安全 stop）。
3. 搭 **PyQt6 主窗口**：`QGraphicsScene` 视频底图 + 空标注层 + 右侧 `QDockWidget` 占位。
4. 写出 **`PCBAffineTracker` / `LocalGlobalTracker` 桩**（类签名、文档字符串、空实现或假矩阵），便于联调。
5. 编写 **测试计划**（`tests/README.md` 或 `docs/TEST_PLAN.md`）：配准成功/失败、投影可见性过滤、JSON 序列化冒烟。
6. 若 `docs/TECH_SPEC.md` 尚不存在：仍可按 `PROJECT_BRIEF.md` 开工；TECH_SPEC 落地后做接口对齐 PR。

### 交付路径（建议）

- `/workspace/pcb-ar-annotate/src/...`
- `/workspace/pcb-ar-annotate/tests/...`
- 可运行：`python -m app.main`（或等价入口）打开空壳窗口 + 相机（无相机时可用假帧）。

### 协作约定

- 不引入打包逻辑；可选依赖 `ultralytics` 先不强制安装。
- 状态色：`unchecked`=红，`checked`=绿；气泡 ≤3 核心参数。

---

## 3. 构建发布 Bot

**角色定位**：依赖管理、桌面封装、发布说明；长期复用于各项目打包与环境冻结。

### 首批任务

1. 起草 **打包计划**（`packaging/PACKAGING_PLAN.md`）：
   - 工具：PyInstaller（首选）
   - 核心依赖：`opencv-python`、`PyQt6`、`numpy`
   - **可选**：`ultralytics`（及 torch）单独 extra，避免默认安装包过大
   - 资源：全局图、Fiducial 模板、模型权重外置路径策略
2. 提供 **环境冻结模板**：
   - `requirements.txt`（核心）
   - `requirements-detect.txt` 或 `requirements-optional.txt`（检测）
   - `requirements-dev.txt`（pytest 等）
3. 预留 PyInstaller `.spec` 草稿（可先注释说明），**在可运行应用与基础测试存在之前不要执行正式打包**。
4. 记录 Windows/Linux 相机权限与常见打包坑（隐藏导入 PyQt6 插件、opencv DLL 等）。

### 交付路径

- `/workspace/pcb-ar-annotate/packaging/PACKAGING_PLAN.md`
- `/workspace/pcb-ar-annotate/requirements.txt`（及 optional/dev 模板）
- （可选）`/workspace/pcb-ar-annotate/packaging/pcb_ar_annotate.spec` 草稿

### 协作约定

- **Gate**：视觉工程给出可启动入口 + 冒烟通过后，再执行首次打包试验。
- 与文档架构对齐：安装说明章节可并入 TECH_SPEC 第 4 阶段或独立 `docs/INSTALL.md`。

---

## 并行顺序建议

```
文档架构 ──► TECH_SPEC / DATA_MODEL / 清单
     │
视觉工程 ──► 同步脚手架（可不等 TECH_SPEC 初稿）──► 按规格对齐
     │
构建发布 ──► 仅计划 + requirements 模板 ──► [有代码后] 打包试验
```

---

## 完成定义（本轮 Handoff）

| 角色 | Done when |
|------|-----------|
| 文档架构 | TECH_SPEC + DATA_MODEL + 里程碑清单 + gaps/risks 已落盘 |
| 视觉工程 | 可启动壳应用 + Capture 线程 + 两个 Tracker 桩 + 测试计划 |
| 构建发布 | 打包计划与依赖模板就绪；明确“暂不打包”门禁 |

更新本文件状态时请注明日期（Asia/Shanghai）与负责人 Bot。
