"""Vision workers.

Capture, tracker stubs, still-tile stitch compare, and VideoMosaicBuilder
live here. Video mosaic is the primary mapping path.
YOLO detection is not part of this tree.
"""
